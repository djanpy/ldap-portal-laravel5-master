<?php

//resources/lang/es/messages.php

return [
    'welcome' => 'Welcome',
    'tittlelogin' => 'Secure access through corporate session',
    'tittleuser' => 'Corporate Username',
    'tittlepass' => 'Corporate password',
    'btnlogin' => 'Login',
    'hello' => 'Hi',
    'panelhome' => 'Application Panel',
    'login' => 'Login',
    'groupsallow' => 'YOU HAVE PERMISSIONS ENABLED IN THE FOLLOWING APPLICATIONS: ',
    'incidentmail' => 'Mail Server',
    'incidentapp' => 'Application Server',
    'incidentprinter' => 'Printer Server',
    'noincident' => 'NO REPORTED'
];
