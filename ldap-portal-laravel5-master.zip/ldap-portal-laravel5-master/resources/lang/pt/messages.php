<?php

//resources/lang/es/messages.php

return [
    'welcome' => 'Bem-vindo/a',
    'tittlelogin' => 'Acesso seguro através da sessão corporativa',
    'tittleuser' => 'Usuário Corporativo',
    'tittlepass' => 'Senha Corporativa',
    'btnlogin' => 'Login',
    'hello' => 'Olá',
    'panelhome' => 'Painel de Aplicação',
    'helptic' => 'Ajuda',
    'logout' => 'Desconectar',
    'login' => 'Login',
    'groupsallow' => 'VOCÊ TEM PERMISSÕES HABILITADAS: ',
    'incidentmail' => 'Servidor de correio',
    'incidentapp' => 'Servidor de Aplicações',
    'incidentprinter' => 'Servidor de Impressão',
    'noincident' => 'NO REPORTED'
];
