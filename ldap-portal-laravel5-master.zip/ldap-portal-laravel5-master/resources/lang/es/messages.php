<?php

//resources/lang/es/messages.php

return [
    'welcome' => 'Bienvenido/a',
    'tittlelogin' => 'Acceso seguro',
    'tittleuser' => 'Usuario Corporativo',
    'tittlepass' => 'Contraseña Corporativa',
    'btnlogin' => 'Iniciar sesión',
    'hello' => 'Hola',
    'panelhome' => 'Panel de aplicaciones',
    'helptic' => 'Ayuda',
    'logout' => 'Cerrar sessión',
    'login' => 'Iniciar sesión',
    'groupsallow' => 'PERMISOS HABILITADOS:',
    'incidentmail' => 'Servidor de correo',
    'incidentapp' => 'Servidor de aplicaciones',
    'incidentprinter' => 'Servidor de impresión',
    'noincident' => 'SIN INCIDENCIAS'
];
