<!--Comprobamos si el status esta a true y existe más de un lenguaje-->
@if (config('locale.status') && count(config('locale.languages')) > 1)
                <div class="nav-item links">
                    <a style="color: white;" href="">{{ App::getLocale() }}  </a> | 
                    @foreach (array_keys(config('locale.languages')) as $lang)
                        
                            @if ($lang != App::getLocale())
                            <a href="{!! route('lang.swap', $lang) !!}">
                                    {!! $lang !!}
                            </a>
                       @endif
                    @endforeach
                </div>
            @endif