@inject('allow','App\Http\Controllers\GroupController')

        @foreach($allow->viewGroupApp() as $group)

                 {{ $group }} , 

        @endforeach
