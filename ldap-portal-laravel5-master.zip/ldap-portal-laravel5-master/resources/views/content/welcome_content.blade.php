</br>
<div>
        <div class="container">
            <div class="row">

                <div class="col-md-6 col-xl-4 mb-4">
    <div class="card shadow border-left-primary py-2" style>
        <div class="card-body">
            <div class="row align-items-center no-gutters">
                <div class="col mr-2">
                    <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>{!! trans('messages.incidentmail') !!}</span></div>
                    <div class="text-dark font-weight-bold h5 mb-0"><span>{!! trans('messages.noincident') !!}</span></div>
                </div>
                <div class="col-auto"><i class="far fa-check-circle fa-2x text-gray-300" style="color: #0fff0a;filter: brightness(47%) grayscale(0%);background-color: rgba(255,255,255,0);opacity: 1;"></i></div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-6 col-xl-4 mb-4">
    <div class="card shadow border-left-primary py-2" style>
        <div class="card-body">
            <div class="row align-items-center no-gutters">
                <div class="col mr-2">
                    <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>{!! trans('messages.incidentapp') !!}</span></div>
                    <div class="text-dark font-weight-bold h5 mb-0"><span>{!! trans('messages.noincident') !!}</span></div>
                </div>
                <div class="col-auto"><i class="far fa-check-circle fa-2x text-gray-300" style="color: #0fff0a;filter: brightness(47%) grayscale(0%);background-color: rgba(255,255,255,0);opacity: 1;"></i></div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-6 col-xl-4 mb-4">
    <div class="card shadow border-left-primary py-2" style>
        <div class="card-body">
            <div class="row align-items-center no-gutters">
                <div class="col mr-2">
                    <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>{!! trans('messages.incidentprinter') !!}</span></div>
                    <div class="text-dark font-weight-bold h5 mb-0"><span>{!! trans('messages.noincident') !!}</span></div>
                </div>
                <div class="col-auto"><i class="far fa-check-circle fa-2x text-gray-300" style="color: #0fff0a;filter: brightness(47%) grayscale(0%);background-color: rgba(255,255,255,0);opacity: 1;"></i></div>
            </div>
        </div>
    </div>
</div>

                <div class="col-md-6">

                <div class="jumbotron shadow border-left-primary py-4" style="background-color: #fff;">
  <h1 class="display-5">lorem ipsum<i class="far fa-thumbs-up"></i></h1>
  <p class="lead"></p>
  <hr class="my-4">
  <p class="lead"></p>
</div>

                </div>

                <div class="col-md-6">
                	<div class="jumbotron shadow border-left-primary py-4" style="background-color: #fff;">
  <h1 class="display-5"> <i class="fab fa-dev"></i></h1>
  <iframe width="464vh" height="240vh" src="https://docs.google.com/spreadsheets/d/e/2PACX-1vRXOYi_65Au-KhsB2i9umDKHulD9tES3SM0OeUnNNLh-yuOJ-aaCC-Wl4K2Pz7-1fg3LfVHvOiVGePt/pubhtml?gid=0&amp;single=true&amp;widget=true&amp;headers=false"></iframe>

</div>

</div>



@auth
<div class="col-md-12">
  <div class="card shadow">
      <div class="card-header">
          <h5 class="mb-0">{!! trans('messages.groupsallow') !!}</h5>
      </div>
      <div class="card-body">
        @include('content.allowgroups')
      </div>
  </div>
</div>

<div class="col-md-12">
  <span></br></span>
</div>
@endauth
                </div>
            </div>
        </div>
    </div>
