<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @include('includes.head')
        <!-- Styles -->
        <style>
            html, body {
                background-image: url('/img/patternlogin.jpg');
                background-size: cover;
                color: #636b6f;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .links > a {
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .color-navbar{
                color: #b0eacd !important;
            }
        </style>
    </head>
    <body>
        @include('includes.header')

        @include('content.welcome_content')

        @include('includes.footer')

    </body>
</html>
