@if (Route::has('login'))
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <a class="navbar-brand links" href="#"><img class="img-fluid" width="90%" src=""></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">

    @include('lang.languages')

    <ul class="navbar-nav ml-auto">
      @auth
      @inject('admin','App\Http\Controllers\GroupController')
      <li class="nav-item links">
        <a class="nav-link" href="{{ route('welcome') }}"><i class="fas fa-angle-up"></i> {!! trans('messages.hello') !!} , {{ Auth::user()->getFirstAttribute('cn') }}</a>
      </li>
      <li class="nav-item links">
        <a class="nav-link" href="{{ route('home') }}"><i class="fas fa-rocket"></i> {!! trans('messages.panelhome') !!}</a>
      </li>
       <li class="nav-item links">
        <a class="nav-link" href="mailto:"><i class="far fa-life-ring"></i> {!! trans('messages.helptic') !!}</a>
      </li>
      @if ($admin->admin())
        <li class="nav-item links">
          <a class="nav-link" href="{{ route('admin') }}"><i class="fas fa-tools"></i> PANEL DE ADMINISTRADOR</a>
        </li>
      @endif
      <li class="nav-item links">
        <a class="nav-link" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i> {!! trans('messages.logout') !!}</a>

                                                      <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
      </li>
      @else
      <li class="nav-item links">
        <a class="nav-link" href="{{ route('welcome') }}"><i class="fas fa-seedling"></i> {!! trans('messages.welcome') !!}</a>
      </li>
      <li class="nav-item links">
        <a class="nav-link" href="mailto:"><i class="far fa-life-ring"></i> {!! trans('messages.helptic') !!}</a>
      </li>
      <li class="nav-item links">
        <a class="nav-link" href="{{ route('login') }}"><i class="fas fa-sign-in-alt"></i> {!! trans('messages.login') !!}</a>
      </li>
      @endauth


    </ul>
  </div>
</nav>
 @endif
