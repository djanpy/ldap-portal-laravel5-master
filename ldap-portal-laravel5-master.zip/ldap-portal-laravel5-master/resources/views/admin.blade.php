<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @include('includes.head')
          <link rel="stylesheet" href="{{ mix('css/app.css') }}">
        <!-- Styles -->
        <style>
            html, body {
                background-image: url('/img/patternlogin.jpg');
                background-size: cover;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .links > a {
                color: #636b6f;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }


        </style>
    </head>
    <body>
        @include('includes.header')

      </br>
      <div class="wrapper" id="app">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-xl-12 mb-12">
                  <router-view></router-view>

                          <vue-progress-bar></vue-progress-bar>

          </div>

        </div>
</div>

</div>

        @include('includes.footer')
<script src="{{ mix('js/app.js') }}"></script>
    </body>
</html>
