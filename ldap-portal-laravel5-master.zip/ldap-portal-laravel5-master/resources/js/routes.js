import Notify from './components/admin/NotifyComponent.vue'

export const routes = [
    {
        path:'/',
        component:Notify
    },



];
