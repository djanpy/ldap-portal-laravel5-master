
<template>
    <div class="container">
        <div class="row mt-5">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Panel de avisos</h3>

                <div class="card-tools">
                    <button class="btn btn-success" data-toggle="modal" data-target="#addNew" @click="openModalWindow">Añadir nuevo aviso <i class="far fa-bell"></i></button>
                </div>
              </div>

              <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                  <tbody>
                    <tr>
                        <th>ID</th>
                        <th>Servidor</th>
                        <th>Prioridad</th>
                        <th>Mensaje</th>
                        <th>Creado</th>
                        <th>Actualizado</th>
                  </tr>

                  <tr v-for="notify in vnotifies" :key="notify.id">
                    <td>{{ notify.id }}</td>
                    <td>{{ notify.ServerName }}</td>
                    <td>{{ notify.PriorityName }}</td>
                    <td>{{ notify.message }}</td>
                    <td>{{ notify.created_at | formatDate}}</td>
                    <td>{{ notify.updated_at | formatDate}}</td>

                    <td>
                        <a href="#" data-id="notify.id" @click="editModalWindow(notify)">
                            <i class="fa fa-edit blue"></i>
                        </a>
                        |
                        <a href="#" @click="deleteNotify(notify.id)">
                            <i class="fa fa-trash red"></i>
                        </a>

                    </td>
                  </tr>
                </tbody></table>
              </div>

              <div class="card-footer">

              </div>
            </div>

          </div>
        </div>


            <div class="modal fade" id="addNew" tabindex="-1" role="dialog" aria-labelledby="addNewLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">

                    <h5 v-show="!editMode" class="modal-title" id="addNewLabel">Añadir nuevo aviso</h5>
                    <h5 v-show="editMode" class="modal-title" id="addNewLabel">Actualizar aviso</h5>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>

<form @submit.prevent="editMode ? updateNotify() : createNotify()">
<div class="modal-body">
     <div class="form-group">

       <p>Servidor afectado:</p>
        <input v-model="form.server" type="radio" name="server" value="1">
        <label for="server1">Servidor de aplicaciones (Izaro, RemoteApps, etc)</label></br>
       <input v-model="form.server" type="radio" name="server" value="2">
        <label for="server2">Servidor de Zona (LDAP, AD, Impresoras red, etc)</label></br>
        <input v-model="form.server" type="radio" name="server" value="3">
        <label for="server2">Servidor de Office 365 (ADFS, Exchange, Teams, etc)</label>


    </div>

     <div class="form-group">
       <p>Prioridad del problema</p>
       <input v-model="form.priority" type="radio" name="priority" value="1">
       <label for="server1">Crítica</label></br>
       <input v-model="form.priority" type="radio" name="priority" value="2">
       <label for="server2">Alta</label></br>
       <input v-model="form.priority" type="radio" name="priority" value="3">
       <label for="server2">Media</label>


    </div>


    <div class="form-group">
        <textarea v-model="form.message" name="message" id="message" placeholder="Describe el problema y el servidor afectado, este mensaje sera público para los usuarios" class="form-control">
      </textarea>
    </div>



</div>
<div class="modal-footer">
    <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
    <button v-show="editMode" type="submit" class="btn btn-primary">Actualizar</button>
    <button v-show="!editMode" type="submit" class="btn btn-primary">Crear</button>
</div>

</form>

                </div>
            </div>
            </div>
    </div>

</template>

<script>
    export default {
        data() {
            return {
                editMode: false,
                vnotifies: {},
                notify: {},
                form: new Form({
                    id: '',
                    server: '',
                    priority : '',
                    message: '',
                })
            }
        },
        methods: {

        editModalWindow(notify){
           this.form.clear();
           this.editMode = true
           this.form.reset();
           $('#addNew').modal('show');
           this.form.fill(notify)
        },
        updateNotify(){
           this.form.put('api/notify/'+this.form.id)
               .then(()=>{

                   Toast.fire({
                      icon: 'success',
                      title: 'Notify updated successfully'
                    })

                    Fire.$emit('AfterCreatedNotifyLoadIt');

                    $('#addNew').modal('hide');
               })
               .catch(()=>{
                  console.log("Error....."+this.form.id)
               })
        },
        openModalWindow(){
           this.editMode = false
           this.form.reset();
           $('#addNew').modal('show');
        },

        loadNotify() {

        //axios.get("api/notify").then( data => (this.notify = data.data));
        axios.get("api/vnotifies").then( data => (this.vnotifies = data.data));
          //pick data from controller and push it into users object

        },

        createNotify(){

            this.$Progress.start()

            this.form.post('api/notify')
                .then(() => {

                    Fire.$emit('AfterCreatedNotifyLoadIt'); //custom events

                        Toast.fire({
                          icon: 'success',
                          title: 'Notify created successfully'
                        })

                        this.$Progress.finish()

                        $('#addNew').modal('hide');

                })
                .catch(() => {
                   console.log("Error......")
                })



            //this.loadUsers();
          },
          deleteNotify(id) {
            Swal.fire({
              title: '¿Seguro que quiere eliminar esta alerta?',
              text: "Esta acción también la desactivara del panel de alertas",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sí, eliminar.'
            }).then((result) => {

              if (result.value) {
                //Send Request to server
                this.form.delete('api/notify/'+id)
                    .then((response)=> {
                            Swal.fire(
                              'Deleted!',
                              'Aviso eliminado correctamente',
                              'success'
                            )
                    this.loadNotify();

                    }).catch(() => {
                        Swal.fire({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                          footer: '<a href>Why do I have this issue?</a>'
                        })
                    })
                }

            })
          }
        },

        created() {
            this.loadNotify();

            Fire.$on('AfterCreatedNotifyLoadIt',()=>{ //custom events fire on
                this.loadNotify();
            });

        }
    }
</script>
