<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use LdapRecord\Models\ActiveDirectory\User;
use LdapRecord\Models\ActiveDirectory\Group;
use Illuminate\Support\Facades\Auth;


class GroupController extends Controller
{

  /**
   * Create a new controller instance.
   *
   * @return void
   */
  public function __construct()
  {
      $this->middleware('auth');
  }

  /**
   * Show the application dashboard.
   *
   * @return \Illuminate\Contracts\Support\Renderable
   */



    public function viewGroupApp(){
        $auth_user = Auth::user()->getAttribute('memberof');



        $patrones = array();
        $patrones[0] = '/CN=/';
        $patrones[1] = '//';
        $patrones[2] = '';
        $patrones[3] = '';
        $patrones[4] = '';
        $patrones[5] = '';
        $patrones[6] = '';
        $patrones[7] = '';
        $patrones[8] = '';
        $patrones[9] = '';
        $sustituciones = array();
        $sustituciones[9] = '';
        $sustituciones[8] = '';
        $sustituciones[7] = '';
        $sustituciones[6] = '';
        $sustituciones[5] = '';
        $sustituciones[4] = '';
        $sustituciones[3] = '';
        $sustituciones[2] = '';
        $sustituciones[1] = '';
        $sustituciones[0] = '';


        $auth_user= preg_replace($patrones, $sustituciones, $auth_user);


        return $auth_user;
    }


    public function admin()
    {

      $isadmin = Auth::user()->getAttribute('memberof');

      $patrones = array();
      $patrones[0] = '//';
      $patrones[1] = '//';
      $patrones[2] = '//';
      $patrones[3] = '//';
      $patrones[4] = '//';
      $patrones[5] = '//';
      $patrones[6] = '//';
      $patrones[7] = '//';
      $patrones[8] = '//';
      $patrones[9] = '//';
      $sustituciones = array();
      $sustituciones[9] = '';
      $sustituciones[8] = '';
      $sustituciones[7] = '';
      $sustituciones[6] = '';
      $sustituciones[5] = '';
      $sustituciones[4] = '';
      $sustituciones[3] = '';
      $sustituciones[2] = '';
      $sustituciones[1] = '';
      $sustituciones[0] = '';


      $istic= preg_replace($patrones, $sustituciones, $isadmin);

      if (in_array("TIC", $istic)) {
        return true;
      } else {
        return false;
      }

    }
}
