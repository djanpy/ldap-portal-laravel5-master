<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model;
use Faker\Generator as Faker;

$factory->define(App\Notify::class, function (Faker $faker) {
    return [
        // Declaramos la fabrica de notificaciones donde vinculamos a SQLite3
        'server' => $faker->numberBetween($min = 1, $max = 3),
        'priority' => $faker->numberBetween($min = 0, $max = 2),
        'message' => $faker->realText($faker->numberBetween(10, 100))
    ];
});
